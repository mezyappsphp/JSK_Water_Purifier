<?php 
include 'navigation.php';
include 'header.php'; 
include 'slidebar.php';
?>

<div id="content-wrapper">
    <div class="container-fluid" id="offer">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <button  class="btn btn-primary" data-toggle="modal" data-target="#myModal">Create New Customer
            </button>
          </li>
        </ol>
         <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i>
           All Customer List</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>                  
                  <th>Sr.No</th>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Address</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  <th>Image</th>
                  <th>Area</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                  <th>Sr.No</th>
                  <th>Code</th>
                  <th>Name</th>
                  <th>Address</th>
                  <th>Mobile</th>
                  <th>Email</th>
                  <th>Image</th>
                  <th>Area</th>
                  <th>Edit</th>
                  <th>Delete</th>
                </tr>
              </tfoot>
              <tbody>
                <?php
                include_once 'config.php';
                $sql="select * from customer_master  ORDER BY cust_id DESC";
                $result=mysqli_query($conn,$sql);  
                $SrNo=1;
                while($details=mysqli_fetch_assoc($result)){
                $id=$details['cust_id'];
                echo"<tr>";
                echo "<td>".$SrNo."</td>";
                echo "<td>".$details['cust_code']."</td>";
                echo "<td style='width:50%'>".$details['cust_name']."</td>";
                echo "<td style='width:50%'>".$details['cust_address']."</td>";
                echo "<td>".$details['cust_mobile']."</td>";
                echo "<td>".$details['cust_email']."</td>";
                echo "<td> <img src='image/".$details['cust_image']."' heigth='30px' 
                width='50px'</td>";
                //echo "<td>".$details['area_id']."</td>";
                $status=$details['status'];
                if($status=="0")
                {
                  $statusValue="Active";
                }
                else
                {
                 $statusValue="InActive"; 
                }
              
                echo "<td><a href='edit_customer.php?edit=$id' class='btn btn-outline-danger' role='button' name='status' id='status'>       
                   ".$statusValue."
                <i class='fas fa-user-edit'></i></a></td>";               


                echo "<td><a href='edit_customer.php?edit=$id' class='btn btn-outline-success' role='button' name='edit' id='edit'>
                   Edit
                <i class='fas fa-edit'></i></a></td>";

                echo "<td><a href='process.php?delete=$id' class='btn btn-outline-danger' role='button' name='delete'id='delete'>Delete
                <i class='fas fa-user-times'></i></a></td>";
                echo"</tr>";
                $SrNo++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
  </div>

</div>
</div>

   <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Add New Customer</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form method="post" action="save_customer.php" enctype="multipart/form-data">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-3">
                <label for="cust_code"> Code</label>
                <input class="form-control" id="cust_code" name="cust_code" type="text" aria-describedby="nameHelp" placeholder="Enter code" 
                required="Enter customer code">
              </div>
              <div class="col-md-9">
                <label for="cust_name"> Name</label>
                <input class="form-control" id="cust_name" 
                name="cust_name" type="text" aria-describedby="nameHelp" 
                placeholder="Enter Name" 
                required="Enter Name">
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
            <label for="cust_address"> Address</label>
            <input class="form-control" id="cust_address" name="cust_address" type="text" aria-describedby="emailHelp" placeholder="Enter  Address" required="Enter Customer Address">
          </div>
        
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-8">
            <label for="cust_email"> Email </label>
            <input class="form-control" id="cust_email" name="cust_email" type="text" aria-describedby="emailHelp" placeholder="Enter Email" required="Enter Customer Email">
          </div>
          <div class="col-md-4">
            <label for="cust_area"> Select Area </label>
            <input class="form-control" id="cust_area" name="cust_area" type="text" aria-describedby="emailHelp" placeholder="Select Area" required="Select Area">
          </div>
           </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-4">
                <label for="cust_mobile">Customer Mobile</label>
                <input class="form-control" id="cust_mobile" name="cust_mobile" 
                type="text" placeholder="Mobile Number" required="Mobile">
              </div>
              <div class="col-md-4">
                <label for="cust_area">Select Status</label>
                <select class="form-control required" name="cust_area">
                    <option value="">Select User Type</option>
                    <option value="1">Active</option>
                    <option value="2">InActive</option>
                  </select>
              </div>
               <div class="col-md-4">
                <label for="cust_image">Customer Image <span style="color:green">(Optional)</span></label>
                 <input class="form-control" id="cust_image" name="cust_image" 
                type="file" placeholder="Select Image" required>
              </div>
            </div>
          </div>
         <!--  <a class="btn btn-primary btn-block" href="login.html">Register</a> -->
         <input type="submit" class="btn btn-block btn-primary -success text-white" name="save">
        </form>
        </div>
      </div>
      </div>
    </div>
    </div>
  </div>
</div>
<?php include 'footer.php'?>  
?>