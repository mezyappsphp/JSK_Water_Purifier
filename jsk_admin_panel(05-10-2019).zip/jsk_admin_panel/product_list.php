<?php
include 'navigation.php';
include 'header.php';
include 'slidebar.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
<div id="content-wrapper">
	<div class="container-fluid" id="product">
		<!---Breadcrumbs -->
		<ol class="breadcrumb">
			<li class="breadcrumb-item">
				<button class="btn btn-success" data-toggle="modal" data-target="#prodModal">Create New Product</button>
			</li><!-- End Li-->
		</ol><!-- End Ol Breadcrumbs-->
		<div class="card md-3">
			<div class="card-header">
				<i class="fa fa-table"></i>&nbsp;All Products List</div><!-- End Of Card Header Div-->
				<div class="card-body">
					<div class="table-responsive" >
						<table class="table table-bordered table-responsive" id="prodTable" width="100%" cellspacing="0">
							<thead>
								<th>Sr No.</th>
								<th>Code</th>
								<th>Code</th>
								<th>Name</th>
								<th>Type</th>
								<th>Discription</th>
								<th>Rate</th>
								<th>warrenty</th>
								<th>Image</th>
								<th>Edit</th>
								<th>Delete</th>
							</thead>
							<tbody>
								<?php
								include_once 'config.php';
								$sql="Select * from product_master ORDER BY prod_id DESC";
								$result=mysqli_query($conn,$sql);
								$SrNo=1;
								while($details=mysqli_fetch_assoc($result)){
									$id=$details['prod_id'];
									echo "<tr>";
									echo "<td>".$SrNo."</td>";
									echo "<td>".$details['prod_id']."</td>";
									echo "<td>".$details['prod_code']."</td>";
									echo "<td>".$details['prod_name']."</td>";
									echo "<td> Finished-Product</td>";
									echo "<td>".$details['prod_desctption']."</td>";
									echo "<td>".$details['prod_rate']."</td>";
									echo "<td>".$details['prod_warrenty']."</td>";
									echo "<td><img src='image/".$details['prod_image']."'heigth='30px'width='50px'</td>";
/*echo '<td><a href="#updprodModal" class="btn btn-outline-success" role="button" name="edit" 
id="<? php echo $details["prod_id"]; ?>" data-toggle="modal" data-target="#updprodModal">
Edit<i class="fas fa-edit"></i></a></td>';
*/
	echo "<td>
		<button type='button' class='btn btn-outline-success editbtn' data-toggle='model' data-target='#editmodel'>
		Edit<i class='fas fa-edit'></i>
		</button>
		</td>";

                echo "<td><a href='process.php?delete=$id' class='btn btn-outline-danger' role='button' name='delete'id='delete'>Delete
                <i class='fas fa-user-times'></i></a></td>";
                echo"</tr>";
                $SrNo++;
            }
			?>
							</tbody><!--End Of Table Body--->
							<tfoot>
								<th>Sr No.</th>
								<th>Code</th>
								<th>Code</th>
								<th>Name</th>
								<th>Type</th>
								<th>Discription</th>
								<th>Rate</th>
								<th>warrenty</th>
								<th>Image</th>
								<th>Edit</th>
								<th>Delete</th>
							</tfoot>
						</table><!-- End Of Table-->
					</div><!--end of Table-->
				</div><!--Card Body-->
		</div><!-- end Col-md-3 div-->
	</div><!-- End Container _fluid--->
</div><!-- content-wrapper--->

<div class="modal fade" id="prodModal" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title text-success">Add New Product</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div><!-- end Of Model Header-->
			<div class="modal-body">
				<form method="post" action="save_product.php" enctype="multipart/form-data">
					<div class="form-group"><!-- 1nd Form Group-->
						<div class="form-row">
							<div class="col-md-3">
								<label for="txtProdCode">Code</label>
								<input class="form-control" type="text" name="txtProdCode" id="txtProdCode" aria-describedby="nameHelp" placeholder="Enter Product Code" required="Enter Product Code">
							</div><!-- end Of col md-3-->
							<div class="col-md-9">
								<label for="txtProdName">Name</label>
								<input class="form-control" type="text" id="txtProdName" name="txtProdName"
								aria-describedby="nameHelp" placeholder="Enter Product Name" required="Enter Product Name">
							</div><!-- end Of Col-md-9-->							
						</div><!--End of form-row-->
					</div><!-- End of form group-->
					<div class="form-group"><!-- 2nd Form Group-->
						<div class="form-row"><!-- form-row-->
						<div class="col-md-12"><!--col-md-12-->
							<label for="txtDescrip">Discription</label>
							<input class="form-control" type="text" name="txtDescrip" id="txtDescrip" aria-describedBy="nameHelp" placeholder="Enter Product Discription" required="Enter Product Discription">
						</div><!-- end Of col-md-12-->
					</div><!-- End Of From _R0w-->
					</div><!--end Of 2nd form group-->
					<div class="form-group"><!--3rd form-control-->
						<div class="form-row">
							<div class="col-md-6">
								<label for="txtPrice">Price</label>
								<input  class="form-control"
								type="number" name="txtPrice" id="txtPrice" aria-descrobedBy="nameHelp" placeholder="Enter Price" required="price">
							</div><!-- End Of col-md-6-->
							<div class="col-md-6">
								<label for="txtProdType">Type</label>
								<select class="form-control required" name="selProdType">
									<option value="">Select Product Type</option>
									<option value="1">Product-Parts</option>
									<option value="2">Finished-Product</option>
								</select>
							</div><!-- End Of Col-md-6-->
						</div><!-- End Of Form Row-->
					</div><!--End of 3rd Form group-->
					<div class="form-group"><!-- form group 4-->
						<div class="form-row">
							<div class="col-md-6">
								<label for="txtWarrenty">Warrenty(In Month)</label>
								<input class="form-control" type="number" name="txtWarrenty" id="txtWarrenty" placeholder="Enter warrenty" required="Warrenty">
							</div><!-- end Of col-md-6-->
							<div class="col-md-6">
								<label for="txtImage">Select Image</label>
								<input class="form-control" type="file" name="txtImage" id="txtImage" required="Select Image">
							</div>
						</div><!-- End Of form-row-->
					</div><!-- End Form form group-->
					<!--<input type="submit" class="btn btn-block btn-primary -success text-white" name="save">-->
					<input type="submit" class="btn btn-block btn-success -success text-white" name="Save">
				</form><!-- End of Form-->
			</div><!--End model-body-->
		</div><!-- end of Model-Content-->
	</div><!-- End Of Model-Dialog-->
</div><!--End Of Model Div-->


<!-- ######################################################################### -->

<div class="modal fade" id="editmodel" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title text-success">Update Product</h4>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div><!--  Model Header-->
			<div class="modal-body">
				<form method="post" action="save_product.php" enctype="multipart/form-data">
					<div class="form-group"><!-- 1nd Form Group-->
						<div class="form-row">
							<div class="col-md-3">
								<label for="txtProdCode">Code</label>
								<input class="form-control" type="text" name="txtProdCode" id="txtProdCode" aria-describedby="nameHelp" placeholder="Enter Product Code" required="Enter Product Code" value="<?php echo $details['prod_code'];?>">
							</div><!-- end Of col md-3-->
							<div class="col-md-9">
								<label for="txtProdName">Name</label>
								<input class="form-control" type="text" id="txtProdName" name="txtProdName"
								aria-describedby="nameHelp" placeholder="Enter Product Name" required="Enter Product Name" value="<?php echo $details['prod_name'];?>">
							</div><!-- end Of Col-md-9-->							
						</div><!--End of form-row-->
					</div><!-- End of form group-->
					<div class="form-group"><!-- 2nd Form Group-->
						<div class="form-row"><!-- form-row-->
						<div class="col-md-12"><!--col-md-12-->
							<label for="txtDescrip">Discription</label>
							<input class="form-control" type="text" name="txtDescrip" id="txtDescrip" aria-describedBy="nameHelp" placeholder="Enter Product Discription" required="Enter Product Discription" value="<?php echo $details['prod_desctption'];?>">
						</div><!-- end Of col-md-12-->
					</div><!-- End Of From _R0w-->
					</div><!--end Of 2nd form group-->
					<div class="form-group"><!--3rd form-control-->
						<div class="form-row">
							<div class="col-md-6">
								<label for="txtPrice">Price</label>
								<input  class="form-control"
								type="number" name="txtPrice" id="txtPrice" aria-descrobedBy="nameHelp" placeholder="Enter Price" required="price" value="<?php echo $details['prod_rate'];?>">
							</div><!-- End Of col-md-6-->
							<div class="col-md-6">
								<label for="txtProdType">Type</label>
								<select class="form-control required" name="selProdType">
									<option value="">Select Product Type</option>
									<option value="1">Product-Parts</option>
									<option value="2">Finished-Product</option>
								</select>
							</div><!-- End Of Col-md-6-->
						</div><!-- End Of Form Row-->
					</div><!--End of 3rd Form group-->
					<div class="form-group"><!-- form group 4-->
						<div class="form-row">
							<div class="col-md-6">
								<label for="txtWarrenty">Warrenty(In Month)</label>
								<input class="form-control" type="number" name="txtWarrenty" id="txtWarrenty" placeholder="Enter warrenty" required="Warrenty" value="<?php echo $details['to_date'];?>">
							</div><!-- end Of col-md-6-->
							<div class="col-md-6">
								<label for="txtImage">Select Image</label>
								<input class="form-control" type="file" name="txtImage" id="txtImage" required="Select Image" value="<?php echo $details['to_date'];?>">
							</div>
						</div><!-- End Of form-row-->
					</div><!-- End Form form group-->
					<!--<input type="submit" class="btn btn-block btn-primary -success text-white" name="save">-->
					<input type="submit" class="btn btn-block btn-success -success text-white" name="Save">
				</form><!-- End of Form-->
			</div><!--End model-body-->
		</div><!-- end of Model-Content-->
	</div><!-- End Of Model-Dialog-->
</div><!--End Of Model Div-->
<script>

	$(document).ready(function(){
		$('.editbtn').on('click', function() {
			$('#editmodel').modal('show');
		});
	});

</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" 
integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" 
integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
</script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" 
integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">
</script>
</body>
</html>
<?php include 'footer.php'?>  