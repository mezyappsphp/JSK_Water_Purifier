<?php
include_once 'config.php';
date_default_timezone_set('Asia/Kolkata');
$updatedDate=date('Y-m-d h:i:sa');
if(isset($_POST['id'],$_POST['name'],$_POST['address']))
{
	$id=$_POST['id'];
	$name=$_POST['name'];
	$address=$_POST['address'];

	$check_already_customer="select cust_id from customer_master where cust_id='".$id."'";

	$check = $conn->query($check_already_customer);
	if($check->num_rows >0)
	{
		$sql="UPDATE customer_master SET cust_name='".$name."',cust_address='".$address."',updated_date='".$updatedDate."' WHERE cust_id='".$id."'";	
		if($conn->query($sql) === TRUE)
		{

			$sql="select cust_id,cust_code,cust_name,cust_address,cust_mobile,cust_email,cust_image from customer_master where cust_id='".$id."'";
			$list=array();
			$result = $conn->query($sql);
			if($result->num_rows >0)
			{
				while($row = $result->fetch_assoc()){
				$list[]=$row;
				}
				if (empty($list)) 
    			{
 	   				$json_array= array('message' => "unsuccess",'code'=>"0",'folder_path'=>"image/",'update_customer'=>$ist);
     				echo json_encode($json_array);
    			}	
    			else
    			{	 
    				 $json_array= array('message' => "success",'code'=>"1",'folder_path'=>"image/",'update_customer'=>$list);
     		 		echo json_encode($json_array); 
     			}
     		}
     	}
     	else
     	{
     	$json_array= array('message' => "unsuccess",'code'=>"0",'folder_path'=>"image/",'update_customer'=>$ist);
     	echo json_encode($json_array);
     	}
	}else
	{
	    	$json_array= array('message' => "unsuccess",'code'=>"0");
     		echo json_encode($json_array); 
	}
}	
else
{

	 $json_array= array('message' => "parameter missing",'code'=>"2");
     echo json_encode($json_array);
}
$conn->close();
?>