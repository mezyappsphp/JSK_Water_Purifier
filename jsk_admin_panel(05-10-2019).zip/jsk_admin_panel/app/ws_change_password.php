<?php
include_once 'config.php';
if(isset($_POST['id'],$_POST['password']))
{
	$id=$_POST['id'];
	$password=$_POST['password'];

	$check_already_customer="select cust_id from customer_master where cust_id='".$id."'";

	$check = $conn->query($check_already_customer);
	if($check->num_rows >0)
	{
		$sql="UPDATE customer_master SET cust_password='".$password."' WHERE cust_id='".$id."'";	
		if($conn->query($sql) === TRUE)
		{
    		$json_array= array('message' => "success",'code'=>"1");
     		echo json_encode($json_array); 
	 	}
	}else
	{
	    	$json_array= array('message' => "unsuccess",'code'=>"0");
     		echo json_encode($json_array); 
	}
}	
else
{

	 $json_array= array('message' => "parameter missing",'code'=>"2");
     echo json_encode($json_array);
}
$conn->close();
?>