<?php
include_once 'config.php';
$list=array();
if(isset($_POST['mobile'],$_POST['password'])){

	$mobile=$_POST['mobile'];
	$password=$_POST['password'];


	$sql="select cust_id,cust_code,cust_name,cust_address,cust_mobile,cust_email,cust_image from customer_master where cust_mobile='".$mobile."' 
		and cust_password='".$password."'";

	$result = $conn->query($sql);
	if($result->num_rows >0)
	{
		while($row = $result->fetch_assoc()){
			$list[]=$row;
		}
		if (empty($list)) 
    	{
 	   		$json_array= array('message' => "unsuccess",'code'=>"0",'folder_path'=>"image/",'customer_login'=>$list);
     		echo json_encode($json_array);
    	}	
    	else
    	{	 
    		 $json_array= array('message' => "success",'code'=>"1",'folder_path'=>"image/",'customer_login'=>$list);
     		 echo json_encode($json_array); 
     	}
	 }
	 else
	 {
	    	$json_array= array('message' => "unsuccess",'code'=>"0",'folder_path'=>"image/",'customer_login'=>$list);
     		 echo json_encode($json_array); 
	 }
}
else
{

	 $json_array= array('message' => "parameter missing",'code'=>"2");
     echo json_encode($json_array);
}
?>