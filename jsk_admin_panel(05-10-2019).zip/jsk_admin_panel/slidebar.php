  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span>
        </a>
      </li>
    
      <li class="nav-item">
        <a class="nav-link" href="customer_list.php">
          <i class="fas fa-fw fa-chart-area"></i>
          <span>Customer Master</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="product_list.php">
          <i class="fas fa-fw fa-table"></i>
          <span>Product Master</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          <i class="fas fa-fw fa-table"></i>
          <span>Request Service</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          <i class="fas fa-fw fa-table"></i>
          <span>Customer Complaint</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          <i class="fas fa-fw fa-table"></i>
          <span>New Installation</span></a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="notification_list.php">
          <i class="fas fa-envelope"></i>
          <span>Notification</span></a>
      </li>
    </ul>
