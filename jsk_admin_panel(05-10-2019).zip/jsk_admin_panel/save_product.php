<?php
session_start();
include_once 'config.php';
date_default_timezone_set('Asia/Kolkata');
$insertedDate=date('Y-m-d h:i:sa');
$prod_code="";
$prod_name="";
$prod_type_id="";
$prod_desctption="";
$prod_rate="";
$prod_image="";
$prod_warrenty="";
$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
if(isset($_POST['Save'])){
	$prod_code=$_POST['txtProdCode'];
	$prod_name=$_POST['txtProdName'];
	$prod_type_id=$_POST['selProdType'];
	$prod_desctption=$_POST['txtDescrip'];
	$prod_rate=$_POST['txtPrice'];
	/*$prod_image=$_POST['txtImage'];*/
	$prod_warrenty=$_POST['txtWarrenty'];

	$img=$_FILES["txtImage"]["name"];
	$type=$_FILES["txtImage"]["type"];
  	$array = explode('.', $img);
  	$fileName=$array[0];
  	$fileExt=$array[1];
  	$newfile=$fileName."_".time().".".$fileExt;

  	if(array_key_exists($fileExt, $allowed)){
  		$check_already_productname="select * from product_master where prod_name='".$prod_name."'";
  		$resultname=$conn->query($check_already_productname);
  		if ($resultname->num_rows>0) {
  			header("Location: http://localhost/jsk_admin_panel/product_list.php");
  			header("product_list.php");
			echo '<script language="javascript">';
			echo 'alert("This Product Name Already Regsitered..")';
			echo '</script>';

  		}
  		/*<!-- name-->*/
  		$check_already_productcode="select * from product_master where prod_code='".$prod_code."'";
  		$result = $conn->query($check_already_productcode);
		if($result->num_rows >0)
		{

		   /*header("Location: http://localhost/jsk_admin_panel/product_list.php");*/
			echo '<script language="javascript">';
			echo 'alert("Product Already Created..")';
			echo 'window.location.href = "product_list.php";';
			echo '</script>';

		}
  		else{

  			$sql="INSERT INTO `product_master`(`prod_code`, `prod_name`, `categary_id`, `prod_desctption`, 
  			`prod_rate`, `prod_image`, `prod_warrenty`) 
  			VALUES ('$prod_code','$prod_name','$prod_type_id',
  			'$prod_desctption','$prod_rate','$newfile','$prod_warrenty')";
		 if(mysqli_query($conn,$sql))
		 {
			/*$_SESSION['message']="Record Updated";*/
			move_uploaded_file($_FILES["txtImage"]["tmp_name"], "image/".$newfile);
			echo '<script type="text/javascript">'; 
			echo 'alert("Record Save successfully");'; 
			echo 'window.location.href = "product_list.php";';
			echo '</script>';
		}
		else
		{
				echo '<script language="javascript">';
				echo 'alert("Somthing went wrong")';
				echo 'window.location.href = "product_list.php";';
				echo '</script>';
		}
		}
  	}
}



?>