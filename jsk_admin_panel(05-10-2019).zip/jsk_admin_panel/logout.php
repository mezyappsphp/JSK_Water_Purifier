<?php
session_start();
 
if(isset($_SESSION["jsk_admin"])){
     unset($_SESSION["jsk_admin"]);
}
session_destroy();
header("Location: login.php");
?>