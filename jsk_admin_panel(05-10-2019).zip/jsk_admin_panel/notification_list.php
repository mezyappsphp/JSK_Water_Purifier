<?php 
include 'navigation.php';
include 'header.php'; 
include 'slidebar.php';
?>

<div id="content-wrapper">
    <div class="container-fluid" id="offer">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <button  class="btn btn-primary" data-toggle="modal" data-target="#myModal">Add New Notification</button>
          </li>
        </ol>
         <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i>
           Notification List List</div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>                  
                  <th>Sr.No</th>
                  <th>Type </th>
                  <th>Title</th>
                  <th>Description</th>
                  <th>Image</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tfoot>
                <tr>
                 <th>Sr.No</th>
                  <th>Type </th>
                  <th>Title</th>
                  <th>Description</th>
                  <th>Image</th>
                  <th>Delete</th>
                </tr>
              </tfoot>
              <tbody>
                <?php
                include_once 'config.php';
                $sql="select * from notification ORDER BY notification_id DESC";
                $result=mysqli_query($conn,$sql);  
                $SrNo=1;
                while($details=mysqli_fetch_assoc($result)){
                echo"<tr>";
                echo "<td>".$SrNo."</td>";
                $type=$details['type'];
                if($type=="0")
                {
                  $typeValue="Public";
                }
                else
                {
                 $typeValue="private"; 
                }
                echo "<td>".$typeValue."</td>";
                echo "<td>".$details['title']."</td>";
                echo "<td style='width:50%'>".$details['description']."</td>";
                echo "<td> <img src='image/".$details['image']."' heigth='30px' 
                width='50px'</td>";
                echo "<td><a href='process.php?delete=$id' class='btn btn-outline-danger' role='button' name='delete'id='delete'>Delete
                <i class='fas fa-user-times'></i></a></td>";
                echo"</tr>";
                $SrNo++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
  </div>

</div>
</div>


   <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Send New Notification</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
        <form method="post" action="send_notifiction.php" enctype="multipart/form-data">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-12">
                <label for="notification_title">Notifiction Title</label>
                <input class="form-control" id="notification_title" name="notification_title" type="text" aria-describedby="nameHelp" placeholder="Enter Notifiction Title" 
                required="Enter Notifiction Title">
              </div>
            </div>
          </div>
           <div class="form-group">
          <div class="form-row">
           <div class="col-md-12">
                <label for="notification_desc">Notifiction Description</label>
                <input class="form-control" id="notification_desc" 
                name="notification_desc" type="text" aria-describedby="nameHelp" 
                placeholder="Enter Notifiction Description" 
                required="Enter Notifiction Description">
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
               <div class="col-md-12">
                <label for="notification_image">Notification Image <span style="color:green">(Optional)</span></label>
                 <input class="form-control" id="notification_image" name="notification_image" 
                type="file" placeholder="Select Notification Image">
              </div>
            </div>
          </div>
         <input type="submit" class="btn btn-block btn-primary -success text-white" name="send">
        </form>
      </div>
    </div>
  </div>
</div>
<?php include 'footer.php'?>  
?>



