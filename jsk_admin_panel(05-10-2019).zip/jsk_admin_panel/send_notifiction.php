<?php
session_start();
include_once 'config.php';
date_default_timezone_set('Asia/Kolkata');
$insertedDate=date('Y-m-d h:i:sa');
$type="0";
$customer_id="";

$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");
if(isset($_POST['save'])){
		$title=$_POST['notification_title'];
		$description=$_POST['notification_desc'];
		$img=$_FILES["notification_image"]["name"];
		$type=$_FILES["notification_image"]["type"];
  		$array = explode('.', $img);
 	 	$fileName=$array[0];
  		$fileExt=$array[1];
  		$newfile=$fileName."_".time().".".$fileExt;

	if(array_key_exists($fileExt, $allowed)) 
   	{
		$sql="INSERT INTO `notification`(`cust_id`, `title`, `description`, `image`, `send_date`, `type`) 
		VALUES ('$customer_id','$title','$description','$newfile','$insertedDate','$type')";

		print_r($sql->Error);
		 if(mysqli_query($conn,$sql)){
			move_uploaded_file($_FILES["notification_image"]["tmp_name"], "image/".$newfile);

			if($type=="0")
			{
				sendPublicNotification($title,$description);
			}
			else
			{

			}
			echo '<script type="text/javascript">'; 
			echo 'alert("notification send successfully");'; 
			echo 'window.location.href = "notification_list.php";';
			echo '</script>';
		}
		else
		{
			echo '<script language="javascript">';
			echo 'alert("Somthing went wrong")';
			echo 'window.location.href = "notification_list.php";';
			echo '</script>';
		}
	}
 }
 else{
 	echo("Not");
 }
function sendPublicNotification($title,$description)
{
    $server_key='AAAAXKGX5Cc:APA91bFx_ZCFZibVdzb4OSCMgVH6FDkHI2Rmr2-yT0YW2iSfmVa7Pb8qm1b5ezVKMPyxdn6TMp_GWazDN0nO45NUJvdcT9TQYn6i3yLi88QFYDhx_iUUBloRIeyPTgnNEwFmglQ_oj5j';
	$url='https://fcm.googleapis.com/fcm/send';

	$notification = array('title' =>$title , 'body' =>$description);
	$arrayToSend = array('to' =>'/topics/WaterPurifier', 'notification' => $notification,'priority'=>'high');
	
    $headers = array(
      'Authorization:key='.$server_key,
      'Content-Type: application/json'
    );
	
    $ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($arrayToSend));
	$result = curl_exec($ch);
	if ($result === FALSE) {
		die('Oops! FCM Send Error: ' . curl_error($ch));
	}
	curl_close($ch);
}
?>