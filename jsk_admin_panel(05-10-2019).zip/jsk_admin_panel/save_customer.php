<?php
session_start();
include_once 'config.php';
date_default_timezone_set('Asia/Kolkata');
$insertedDate=date('Y-m-d h:i:sa');
$cust_code="";
$cust_name="";
$cust_address="";
$cust_mobile="";
$cust_email="";
$cust_password="";
$area_id="";
$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");

if(isset($_POST['save'])){
	$cust_code=$_POST['cust_code'];
	$cust_name=$_POST['cust_name'];
	$cust_address=$_POST['cust_address'];
	$cust_mobile=$_POST['cust_mobile'];
	$cust_email=$_POST['cust_email'];
	//$cust_password=$_POST['cust_mobile'];
	$area_id=$_POST['cust_area'];

	$img=$_FILES["cust_image"]["name"];
	$type=$_FILES["cust_image"]["type"];
  	$array = explode('.', $img);
  	$fileName=$array[0];
  	$fileExt=$array[1];
  	$newfile=$fileName."_".time().".".$fileExt;

	if(array_key_exists($fileExt, $allowed)) 
   	{
		$check_already_customer="select cust_mobile from customer_master where cust_mobile='".$cust_mobile."'";
		$result = $conn->query($check_already_customer);
		if($result->num_rows >0)
		{

		   header("Location: http://localhost/jsk_admin_panel/customer_list.php");
			echo '<script language="javascript">';
			echo 'alert("Customer Already Regsitered..")';
			echo '</script>';

		}
		else
		{ 
		  $sql="INSERT INTO `customer_master`(`cust_code`, `cust_name`, `cust_address`, `cust_mobile`, `cust_email`, `cust_password`, `cust_image`, `status`,`created_date`) 
			VALUES ('$cust_code','$cust_name','$cust_address','$cust_mobile','$cust_email',
			'$cust_mobile',	'$newfile','$area_id','$insertedDate')";

		 if(mysqli_query($conn,$sql)){
			$_SESSION['message']="Record Updated";
			move_uploaded_file($_FILES["cust_image"]["tmp_name"], "image/".$newfile);
			echo '<script type="text/javascript">'; 
			echo 'alert("Record Save successfully");'; 
			echo 'window.location.href = "customer_list.php";';

			echo '</script>';
		}
		else
		{
			echo '<script language="javascript">';
			echo 'alert("Somthing went wrong")';
			echo 'window.location.href = "customer_list.php";';
			echo '</script>';
		}
	}
 }
}
?>