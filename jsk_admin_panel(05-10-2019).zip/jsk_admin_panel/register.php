<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>The Biryani House</title>

  <link rel = "icon" type = "image/png" href = "image/icon.png">
  
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">

</head>

<body class="" style="color:white;background-color:#1ABC9C">

  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header text-center" style="color:white;background-color:#7D3C98">
        <h5>Register an Account</h5></div>
      <div class="card-body">
        <form action="" method="post">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="text" id="firstName" class="form-control" placeholder="First name" required="required" autofocus="autofocus" name="firstName" style="color:#7D3C98;border-color: #7D3C98;">
                  <label for="firstName" style="color:#7D3C98;">First name</label>
                </div>
              </div>
              <div class="col-md-6">
                <div class="form-label-group">
                  <input type="text" id="lastName" class="form-control" placeholder="Last name" required="required" name="lastName" style="color:#7D3C98;border-color: #7D3C98;">
                  <label for="lastName" style="color:#7D3C98;">Last name</label>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
              <input type="text" id="inputEmail" class="form-control" placeholder="User Name" required="required" name="textEmail" style="color:#7D3C98;border-color: #7D3C98;">
              <label for="inputEmail" style="color:#7D3C98;">User Name</label>
            </div>
          </div>
          <div class="form-group">
            <div class="form-label-group">
                  <input type="password" id="inputPassword" class="form-control" placeholder="Password" required="required" name="inputPassword" style="color:#7D3C98;border-color: #7D3C98;">
                  <label for="inputPassword" style="color:#7D3C98;">Password</label>
            </div>
          </div>
          <input type="submit" name="submit" value="Register" class="btn btn-block" style="background-color:#7D3C98;color:white"/>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="index.php" style="color:#7D3C98;">Login Page</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>
</html>

<?php
include_once 'config.php';
if (isset($_POST['submit'])) {
  $firstName=$_POST["firstName"];
  $lastName=$_POST["lastName"];
  $textEmail=$_POST["textEmail"];
  $textPassword=$_POST["inputPassword"];
  $name=$firstName." ".$lastName;
  $password=base64_encode($textPassword);//Convert to base 64


  $sql = "INSERT INTO admins(name,email,password) VALUES('$name','$textEmail', '$password')";
      if ($conn->query($sql) === TRUE) {
			echo '<script type="text/javascript">'; 
			echo 'alert("Registration successfully");'; 
			echo 'window.location.href = "login.php";';
			echo '</script>';
      } else {
          echo '<script type="text/javascript">'; 
          echo 'alert("Incorect Unsername Or Password");'; 
          echo '</script>';
             
      }

}
?>